// Import required libraries
const express = require('express');
const bodyParser = require('body-parser');
const cors = require('cors');
const app = express(); // Create the server
const PORT = 3000;    // Port number (like a door number for your server)

// Middleware (tools to process requests)
app.use(cors()); // Allow frontend-backend communication
app.use(bodyParser.json()); // Parse JSON data (e.g., from API requests)
app.use(express.static('frontend')); // Serve HTML/CSS/JS files from 'frontend' folder

// Test route (to check if the backend is working)
app.get('/api/test', (req, res) => {
  res.json({ message: "Backend is alive!" });
});

// Start the server
app.listen(PORT, () => {
  console.log(`Server is running on http://localhost:${PORT}`);
});
