   const express = require('express');
   const mysql = require('mysql');
   const bodyParser = require('body-parser');
   const cors = require('cors');

   const app = express();
   const port = 3000;

   // Middleware
   app.use(cors());
   app.use(bodyParser.json());

   // MySQL connection
   const db = mysql.createConnection({
     host: 'localhost',
     user: 'your_username', // replace with your MySQL username
     password: 'your_password', // replace with your MySQL password
     database: 'diet_planner' // replace with your database name
   });

   db.connect(err => {
     if (err) {
       console.error('Error connecting to MySQL:', err);
       return;
     }
     console.log('Connected to MySQL');
   });

   // API endpoints
   app.post('/api/login', (req, res) => {
     const { email, password } = req.body;
     const query = 'SELECT * FROM users WHERE email = ? AND password = ?';
     db.query(query, [email, password], (err, results) => {
       if (err) {
         return res.status(500).json({ error: 'Database error' });
       }
       if (results.length > 0) {
         res.json({ success: true, user: results[0] });
       } else {
         res.status(401).json({ success: false, message: 'Invalid email or password' });
       }
     });
   });

   app.post('/api/signup', (req, res) => {
     const { name, email, password } = req.body;
     const query = 'INSERT INTO users (name, email, password) VALUES (?, ?, ?)';
     db.query(query, [name, email, password], (err, results) => {
       if (err) {
         return res.status(500).json({ error: 'Database error' });
       }
       res.json({ success: true, user: { name, email } });
     });
   });

   app.listen(port, () => {
     console.log(`Server running at http://localhost:${port}`);
   });
   